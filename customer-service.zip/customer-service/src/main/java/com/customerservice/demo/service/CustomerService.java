package com.customerservice.demo.service;

import java.util.ArrayList;
import java.util.*;

import org.springframework.stereotype.Service;
import com.customerservice.demo.model.Customer;

import javax.persistence.Entity;

import com.customerservice.demo.repository.CustomerRepository;

@Service
public class CustomerService {

	private CustomerRepository cusRepo;

	public CustomerService(CustomerRepository cusRepo) {
		super();
		this.cusRepo = cusRepo;
	}
	
	public List<Customer> getAllCustomers(){
		return this.cusRepo.findAll();
		
	}
	
	public Customer addCustomer(Customer entity){
		return this.cusRepo.save(entity);
		
	}
	
	public void deleteCustomer(int entityId){
		this.cusRepo.deleteById(entityId);
		
	}
	
	/*
	 * public Optional<Customer> removeCustomer(Customer customer){
	 * Optional<Customer> response=Optional.empty() }
	 */

	
	public Optional<Customer> getCustomerById(int id) {
		
		 return this.cusRepo.findById(id);
	}
	
	public Customer update(Customer customer) {
		
		return this.cusRepo.save(customer);
	}
	
	public Optional<Customer> removeCustomer(Customer customer){
		
		Optional<Customer> response = Optional.empty();
		
		if(this.cusRepo.existsById(customer.getId())) {
			
			   this.cusRepo.delete(customer);
			   
			   response = Optional.of(customer);
		}
		
		return response;
	}
	
	public List<Customer> findByName(String srchName){
		
		 return this.cusRepo.findByName(srchName);
		
	}
	
	
}
