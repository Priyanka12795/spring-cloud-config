package com.customerservice.demo.repository;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;

import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.support.JpaRepositoryFactory;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.customerservice.demo.model.Customer;

@Repository
public interface CustomerRepository extends JpaRepository<Customer,Integer> {

	List<Customer> findByName(String srchName);
	  
	  
	  @Query(value ="select id ,name from Customer where id=:id",nativeQuery = true)
	  Customer findSlectiveColumn(String srchName);

  @Query(value = "update Customer set email = :updateMail where id=:srchId")
	@Modifying
	@Transactional
	public int updateMail(@Param("srchId") int id,@Param("updateMail") String updateMail);
	



	
}
